exports.categories = ["coo", "equ", "geo", "sfw"];
exports.purposes = ["fcn", "per", "adm", "ana", "com", "trd", "loc"];

exports.consentHeader = 'x-accept-privacy';
exports.ackHeader = 'x-privacy';